<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\BusinessResource;
use App\Models\Business;
use App\Models\Destination;
use Illuminate\Http\Request;

class BusinessController extends Controller
{
    public function index(Request $request)
    {
        $validated = $request->validate([
            'destination' => 'nullable|string|exists:destinations,slug',
            'category' => 'nullable|string|exists:business_categories,slug',
            'commune_id' => 'nullable|integer|exists:communes,id',
            'per_page' => 'nullable|integer|min:1|max:50',
        ]);

        $query = Business::query()
            ->active()
            ->with(['category', 'commune'])
            ->withCoordinates();

        if (! empty($validated['destination'])) {
            $destination = Destination::where('slug', $validated['destination'])->firstOrFail();
            $query->inDestination($destination->id);
        }

        if (! empty($validated['category'])) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $validated['category']));
        }

        if (! empty($validated['commune_id'])) {
            $query->where('commune_id', $validated['commune_id']);
        }

        $businesses = $query->paginate($validated['per_page'] ?? 20);

        return BusinessResource::collection($businesses);
    }

    public function show(string $slug)
    {
        $business = Business::query()
            ->active()
            ->where('slug', $slug)
            ->with(['category', 'commune', 'contacts', 'socials', 'services'])
            ->withCoordinates()
            ->firstOrFail();

        return new BusinessResource($business);
    }
}

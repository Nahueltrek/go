<?php

use App\Http\Controllers\Api\V1\ActivityController;
use App\Http\Controllers\Api\V1\ArticleController;
use App\Http\Controllers\Api\V1\AttractionController;
use App\Http\Controllers\Api\V1\BusinessController;
use App\Http\Controllers\Api\V1\DestinationController;
use App\Http\Controllers\Api\V1\EventController;
use App\Http\Controllers\Api\V1\MapController;
use App\Http\Controllers\Api\V1\RouteController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    Route::get('destinations/{slug}', [DestinationController::class, 'show']);

    Route::get('businesses', [BusinessController::class, 'index']);
    Route::get('businesses/{slug}', [BusinessController::class, 'show']);

    Route::get('attractions', [AttractionController::class, 'index']);
    Route::get('attractions/{slug}', [AttractionController::class, 'show']);

    Route::get('activities', [ActivityController::class, 'index']);
    Route::get('activities/{slug}', [ActivityController::class, 'show']);

    Route::get('routes', [RouteController::class, 'index']);
    Route::get('routes/{slug}', [RouteController::class, 'show']);

    Route::get('articles', [ArticleController::class, 'index']);
    Route::get('articles/{slug}', [ArticleController::class, 'show']);

    Route::get('events', [EventController::class, 'index']);
    Route::get('events/{slug}', [EventController::class, 'show']);

    Route::get('map/nearby', [MapController::class, 'nearby']);

    // Endpoints autenticados (crear/editar negocio, reclamar ficha, favoritos)
    // se agregan en la fase de Dashboard del emprendedor — no forman parte
    // de este primer corte de API pública de solo lectura.
});

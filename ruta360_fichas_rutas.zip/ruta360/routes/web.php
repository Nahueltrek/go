<?php

use App\Http\Controllers\Public\AttractionShowController;
use App\Http\Controllers\Public\BusinessShowController;
use App\Http\Controllers\Public\HomeController;
use App\Http\Controllers\Public\RouteShowController;
use Illuminate\Support\Facades\Route;

Route::get('/', HomeController::class)->name('home');
Route::get('/emprendimientos/{slug}', BusinessShowController::class)->name('businesses.show');
Route::get('/atractivos/{slug}', AttractionShowController::class)->name('attractions.show');
Route::get('/rutas/{slug}', RouteShowController::class)->name('routes.show');

// NOTA: /blog/{slug} queda para la fase de Blog del roadmap.

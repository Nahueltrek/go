<script setup>
import { router, usePage } from '@inertiajs/vue3'

const props = defineProps({
  organizations: Object,
  activeStatus: String,
})

const page = usePage()
const statuses = [
  { key: 'approved', label: 'Activos' },
  { key: 'pending', label: 'Pendientes' },
  { key: 'rejected', label: 'Suspendidos' },
  { key: 'all', label: 'Todos' },
]

function filterBy(status) {
  router.get('/admin/organizaciones', { status }, { preserveState: true })
}

function approve(id) {
  router.post(`/admin/organizaciones/${id}/approve`, {}, { preserveScroll: true })
}

function suspend(id) {
  router.post(`/admin/organizaciones/${id}/suspend`, {}, { preserveScroll: true })
}
</script>

<template>
  <div class="min-h-screen bg-sky-50 px-4 py-6">
    <h1 class="text-lg font-semibold text-sky-900 mb-1">Operadores</h1>

    <div v-if="page.props.flash?.success" class="mt-3 rounded-xl bg-green-50 text-green-800 text-sm p-3">
      {{ page.props.flash.success }}
    </div>

    <div class="flex gap-2 mt-4 mb-4 overflow-x-auto no-scrollbar">
      <button
        v-for="s in statuses"
        :key="s.key"
        @click="filterBy(s.key)"
        class="shrink-0 rounded-full px-3 py-1.5 text-xs font-medium"
        :class="activeStatus === s.key ? 'bg-sky-900 text-white' : 'bg-white border border-sky-200 text-sky-600'"
      >{{ s.label }}</button>
    </div>

    <div class="space-y-3">
      <div v-for="org in organizations.data" :key="org.id" class="rounded-2xl bg-white border border-sky-100 p-4">
        <div class="flex gap-3 items-center">
          <div class="h-10 w-10 shrink-0 rounded-xl bg-sky-100 overflow-hidden">
            <img v-if="org.logo_url" :src="org.logo_url" class="h-full w-full object-cover" />
          </div>
          <div class="min-w-0 flex-1">
            <p class="text-sm font-medium text-sky-900 truncate">{{ org.name }}</p>
            <p class="text-xs text-sky-500 capitalize">{{ org.type }} · {{ org.commune?.name }}</p>
          </div>
        </div>

        <div class="flex gap-2 mt-3" v-if="activeStatus !== 'rejected'">
          <button v-if="org.status !== 'approved'" @click="approve(org.id)"
                  class="flex-1 text-xs font-medium rounded-full bg-sky-900 text-white py-2">Aprobar</button>
          <button v-if="org.status === 'approved'" @click="suspend(org.id)"
                  class="flex-1 text-xs font-medium rounded-full border border-sky-200 py-2">Suspender</button>
        </div>
        <button v-else @click="approve(org.id)"
                class="w-full mt-3 text-xs font-medium rounded-full border border-sky-200 py-2">Reactivar</button>
      </div>

      <p v-if="!organizations.data?.length" class="text-sm text-sky-400 text-center py-12">
        No hay operadores en este estado.
      </p>
    </div>
  </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar { display: none; }
.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
</style>

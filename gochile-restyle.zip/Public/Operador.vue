<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  organization: Object,
  experiences: Object,
  projects: Object,
})
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <!-- Header -->
    <header class="px-4 pt-6 pb-4 border-b border-sky-100">
      <div class="flex items-center gap-3">
        <div class="h-16 w-16 shrink-0 rounded-2xl bg-sky-100 overflow-hidden">
          <img v-if="organization.logo_url" :src="organization.logo_url" class="h-full w-full object-cover" />
        </div>
        <div class="min-w-0">
          <p class="text-xs uppercase tracking-wide text-sky-400">{{ organization.type }}</p>
          <h1 class="text-lg font-semibold text-sky-900 truncate">{{ organization.name }}</h1>
          <p class="text-xs text-sky-500">{{ organization.commune?.name }}</p>
        </div>
      </div>

      <p v-if="organization.description" class="text-sm text-sky-600 mt-4 leading-relaxed">
        {{ organization.description }}
      </p>

      <div class="flex gap-2 mt-4 flex-wrap">
        <span
          v-for="cat in organization.categories"
          :key="cat"
          class="text-xs rounded-full border border-sky-200 px-2.5 py-1 text-sky-600"
        >{{ cat }}</span>
      </div>

      <div class="flex gap-3 mt-4">
        <a v-if="organization.whatsapp" :href="`https://wa.me/${organization.whatsapp}`"
           class="text-sm font-medium rounded-full bg-sky-900 text-white px-4 py-2">WhatsApp</a>
        <a v-if="organization.instagram" :href="organization.instagram"
           class="text-sm font-medium rounded-full border border-sky-200 px-4 py-2">Instagram</a>
        <a v-if="organization.website" :href="organization.website"
           class="text-sm font-medium rounded-full border border-sky-200 px-4 py-2">Sitio web</a>
      </div>
    </header>

    <!-- Experiencias -->
    <section v-if="experiences.data?.length" class="px-4 py-6 space-y-3">
      <h2 class="text-sm font-semibold text-sky-900">Experiencias</h2>
      <Link
        v-for="exp in experiences.data"
        :key="exp.id"
        :href="`/experiencias/${exp.slug}`"
        class="flex gap-3 rounded-2xl border border-sky-100 p-3 active:bg-sky-50"
      >
        <div class="h-16 w-16 shrink-0 rounded-xl bg-sky-100 overflow-hidden">
          <img v-if="exp.images?.[0]" :src="exp.images[0]" class="h-full w-full object-cover" />
        </div>
        <div class="min-w-0 flex-1">
          <p class="text-sm font-medium text-sky-900 truncate">{{ exp.name }}</p>
          <p class="text-xs text-sky-500">{{ exp.activity_type }} · {{ exp.difficulty }}</p>
        </div>
      </Link>
    </section>

    <!-- Proyectos -->
    <section v-if="projects.data?.length" class="px-4 py-6 space-y-3">
      <h2 class="text-sm font-semibold text-sky-900">Proyectos</h2>
      <Link
        v-for="p in projects.data"
        :key="p.id"
        :href="`/proyectos/${p.slug}`"
        class="flex gap-3 rounded-2xl border border-sky-100 p-3 active:bg-sky-50"
      >
        <div class="h-16 w-16 shrink-0 rounded-xl bg-sky-100 overflow-hidden">
          <img v-if="p.images?.[0]" :src="p.images[0]" class="h-full w-full object-cover" />
        </div>
        <div class="min-w-0 flex-1">
          <p class="text-sm font-medium text-sky-900 truncate">{{ p.name }}</p>
        </div>
      </Link>
    </section>
  </div>
</template>

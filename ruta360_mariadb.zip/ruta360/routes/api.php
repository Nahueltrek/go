<?php

use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Endpoints mínimos definidos en el plan maestro:
    // GET /businesses, /businesses/{slug}, /attractions, /routes, /activities,
    // /articles, /events, /map/nearby, /destinations/{slug}
    // Se implementan en la fase de API (Fase 5) con sus Controllers y API Resources.
});

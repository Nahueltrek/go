<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  project: Object,
})

const categoryLabels = {
  conservacion: 'Conservación',
  geologia: 'Geología',
  biodiversidad: 'Biodiversidad',
  comunidad: 'Comunidad',
}
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <header class="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-sky-100 px-4 py-2.5 flex items-center gap-2">
      <Link href="/" class="shrink-0">
        <img src="/images/logo.png" alt="GO Chile" class="h-7 w-7 rounded-full" />
      </Link>
      <span class="text-xs font-bold text-sky-950">GO Chile</span>
    </header>

    <div class="h-56 w-full bg-sky-100 overflow-hidden">
      <img v-if="project.images?.[0]" :src="project.images[0]" class="h-full w-full object-cover" />
    </div>

    <div class="px-4 py-5">
      <p class="text-xs uppercase tracking-wide text-sky-400">
        {{ categoryLabels[project.category] || project.category }}
      </p>
      <h1 class="text-xl font-semibold text-sky-900 mt-0.5">{{ project.name }}</h1>

      <Link
        v-if="project.organization"
        :href="`/operadores/${project.organization.slug}`"
        class="text-sm text-sky-500 underline"
      >{{ project.organization.name }}</Link>

      <p v-if="project.description" class="text-sm text-sky-600 mt-5 leading-relaxed">
        {{ project.description }}
      </p>

      <section v-if="project.how_to_collaborate" class="mt-6 rounded-2xl bg-sky-50 p-4">
        <h2 class="text-sm font-semibold text-sky-900 mb-2">🤝 Cómo colaborar</h2>
        <p class="text-sm text-sky-600 leading-relaxed">{{ project.how_to_collaborate }}</p>
      </section>
    </div>
  </div>
</template>

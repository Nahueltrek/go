<script setup>
import { Link } from '@inertiajs/vue3'
import { useForm, usePage } from '@inertiajs/vue3'

defineProps({
  regions: Array,
  types: Array,
})

const typeLabels = {
  guia: 'Guía', operador: 'Operador', agencia: 'Agencia', emprendimiento: 'Emprendimiento',
  alojamiento: 'Alojamiento', marca: 'Marca', proyecto: 'Proyecto', organizacion: 'Organización',
}

const form = useForm({
  type: '', name: '', region_id: '', instagram: '', website: '', whatsapp: '', description: '',
})

const page = usePage()

function submit() {
  form.post('/colaboradores', { preserveScroll: true, onSuccess: () => form.reset() })
}
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <header class="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-sky-100 px-4 py-2.5 flex items-center gap-2">
      <Link href="/" class="shrink-0">
        <img src="/images/logo.png" alt="GO Chile" class="h-7 w-7 rounded-full" />
      </Link>
      <span class="text-xs font-bold text-sky-950">GO Chile</span>
    </header>

    <header class="px-4 pt-6 pb-4 border-b border-sky-100">
      <h1 class="text-lg font-semibold text-sky-900">🤝 Quiero ser parte de GO Chile</h1>
      <p class="text-xs text-sky-500 mt-1">
        Guías, operadores, agencias, alojamientos, marcas y proyectos territoriales — sumate a la red.
      </p>
    </header>

    <div v-if="page.props.flash?.success" class="mx-4 mt-4 rounded-xl bg-green-50 text-green-800 text-sm p-3">
      {{ page.props.flash.success }}
    </div>

    <form @submit.prevent="submit" class="px-4 py-5 space-y-4">
      <div>
        <label class="text-xs font-medium text-sky-600">Tipo de colaborador</label>
        <select v-model="form.type" required class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm">
          <option value="" disabled>Seleccionar…</option>
          <option v-for="t in types" :key="t" :value="t">{{ typeLabels[t] || t }}</option>
        </select>
        <p v-if="form.errors.type" class="text-xs text-red-600 mt-1">{{ form.errors.type }}</p>
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">Nombre</label>
        <input v-model="form.name" required type="text"
               class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm" />
        <p v-if="form.errors.name" class="text-xs text-red-600 mt-1">{{ form.errors.name }}</p>
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">Región</label>
        <select v-model="form.region_id" class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm">
          <option value="">Seleccionar…</option>
          <option v-for="r in regions" :key="r.id" :value="r.id">{{ r.name }}</option>
        </select>
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">Instagram</label>
        <input v-model="form.instagram" type="text" placeholder="@tuemprendimiento"
               class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm" />
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">Sitio web</label>
        <input v-model="form.website" type="url" placeholder="https://"
               class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm" />
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">WhatsApp</label>
        <input v-model="form.whatsapp" type="text" placeholder="+56 9…"
               class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm" />
      </div>

      <div>
        <label class="text-xs font-medium text-sky-600">Contanos qué hacés</label>
        <textarea v-model="form.description" rows="4"
                  class="w-full mt-1 rounded-xl border border-sky-200 px-3 py-2.5 text-sm"></textarea>
      </div>

      <button type="submit" :disabled="form.processing"
              class="w-full text-sm font-medium rounded-full bg-sky-900 text-white py-3 disabled:opacity-50">
        {{ form.processing ? 'Enviando…' : 'Enviar postulación' }}
      </button>
    </form>
  </div>
</template>

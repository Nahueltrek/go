<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  stats: Object,
})

const cards = [
  { key: 'colaboraciones_pendientes', label: 'Postulaciones pendientes', href: '/admin/colaboradores', highlight: true },
  { key: 'organizaciones_pendientes', label: 'Operadores pendientes', href: '/admin/organizaciones?status=pending', highlight: true },
  { key: 'organizaciones_aprobadas', label: 'Operadores activos', href: '/admin/organizaciones' },
  { key: 'experiencias_publicadas', label: 'Experiencias publicadas' },
  { key: 'proyectos_publicados', label: 'Proyectos publicados' },
  { key: 'eventos_proximos', label: 'Eventos próximos', href: '/agenda' },
  { key: 'articulos_publicados', label: 'Artículos en Bitácora', href: '/bitacora' },
]
</script>

<template>
  <div class="min-h-screen bg-sky-50 px-4 py-6">
    <header class="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-sky-100 -mx-4 px-4 py-2.5 mb-4 flex items-center gap-2">
      <Link href="/" class="shrink-0">
        <img src="/images/logo.png" alt="GO Chile" class="h-7 w-7 rounded-full" />
      </Link>
      <span class="text-xs font-bold text-sky-950">GO Chile · Admin</span>
    </header>

    <h1 class="text-lg font-semibold text-sky-900 mb-4">Panel GO Chile</h1>

    <div class="grid grid-cols-2 gap-3">
      <component
        v-for="c in cards"
        :key="c.key"
        :is="c.href ? Link : 'div'"
        :href="c.href"
        class="rounded-2xl bg-white border p-4"
        :class="c.highlight && stats[c.key] > 0 ? 'border-amber-300' : 'border-sky-100'"
      >
        <p class="text-2xl font-semibold text-sky-900">{{ stats[c.key] }}</p>
        <p class="text-xs text-sky-500 mt-1">{{ c.label }}</p>
      </component>
    </div>
  </div>
</template>

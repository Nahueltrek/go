<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\RouteResource;
use App\Models\Destination;
use App\Models\Route as TrailRoute;
use Illuminate\Http\Request;

class RouteController extends Controller
{
    public function index(Request $request)
    {
        $validated = $request->validate([
            'destination' => 'nullable|string|exists:destinations,slug',
            'per_page' => 'nullable|integer|min:1|max:50',
        ]);

        $query = TrailRoute::query();

        if (! empty($validated['destination'])) {
            $destination = Destination::where('slug', $validated['destination'])->firstOrFail();
            $query->where('destination_id', $destination->id);
        }

        return RouteResource::collection($query->paginate($validated['per_page'] ?? 20));
    }

    public function show(string $slug)
    {
        $route = TrailRoute::query()
            ->where('slug', $slug)
            ->with('points.pointable')
            ->firstOrFail();

        return new RouteResource($route);
    }
}

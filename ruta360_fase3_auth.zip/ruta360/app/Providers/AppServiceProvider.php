<?php

namespace App\Providers;

use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Nombres cortos en las columnas *_type de las relaciones polimórficas
        // (route_points.pointable_type, article_relations.relatable_type,
        // media/galleries.*able_type, favorites.favoritable_type) — así no
        // queda el namespace completo (App\Models\Business) guardado en la
        // base de datos, lo que rompería si algún día se reorganizan carpetas.
        Relation::enforceMorphMap([
            'business' => \App\Models\Business::class,
            'attraction' => \App\Models\Attraction::class,
            'activity' => \App\Models\Activity::class,
            'route' => \App\Models\Route::class,
            'article' => \App\Models\Article::class,
            'destination' => \App\Models\Destination::class,
        ]);
    }
}

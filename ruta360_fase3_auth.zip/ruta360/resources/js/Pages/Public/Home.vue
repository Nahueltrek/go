<script setup>
// Placeholder de la página de inicio — el diseño real (buscador, mapa,
// experiencias destacadas, etc.) se implementa en la fase "Portal Turístico"
// del roadmap, siguiendo la guía de frontend-design del proyecto.
</script>

<template>
  <div class="min-h-screen flex items-center justify-center">
    <div class="text-center">
      <h1 class="text-2xl font-semibold">Ruta Cajón del Maipo 360</h1>
      <p class="text-gray-500 mt-2">En construcción — Fase 1: infraestructura y base de datos.</p>
    </div>
  </div>
</template>

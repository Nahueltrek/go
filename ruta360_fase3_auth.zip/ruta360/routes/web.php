<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Public/Home');
})->name('home');

// NOTA: rutas reales de /emprendimientos/{slug}, /atractivos/{slug}, /rutas/{slug},
// /blog/{slug}, /destinos/{slug}, /dashboard y /admin se agregan en las fases
// correspondientes (Fichas, Blog, Dashboard emprendedor, Administración) — ver roadmap.

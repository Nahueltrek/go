# GO Chile 2.0 — Guía de despliegue en go.0km.app

## Situación real (importante leer antes de tocar el servidor)

1. **go.0km.app hoy corre un Laravel distinto y más simple** que rm360 (el taller fijo, info institucional) — no comparte base de datos ni esquema con rm360.0km.app. Esto no es un ALTER sobre datos existentes de rm360: es reemplazar el sitio actual por una instalación nueva basada en el código de rm360 + estas extensiones.

2. **El código base completo de rm360 no está en este paquete.** Todo lo que armamos en esta conversación son las piezas nuevas de GO Chile 2.0 (Fase 1 en adelante: jerarquía territorial, organizations, experiences, projects, blog, colaboradores, buscador, mapa, fichas). Los modelos y migraciones originales de rm360 (`Business`, `Route`, `Destination`, `Attraction`, `Media`, `BusinessCategory`, autenticación, etc. — 36+ migraciones) fueron escritos en una conversación anterior, en un contenedor de trabajo que ya no existe. No están en ningún repo — vos mismo lo confirmaste.

3. **De dónde sacar el código base real de rm360**: la única copia confiable y actualizada es la que **ya está corriendo en producción** en `rm360.0km.app`, en la misma cuenta Hostinger (`u451636252`). Esa es la fuente de verdad — no la conversación (que puede tener versiones intermedias con bugs ya corregidos en producción, como pasó hoy con `favorites`).

## Recomendación de proceso

Esto **no se puede hacer completo desde este chat** — yo no tengo acceso SSH ni de red a tu hosting. El camino más seguro es con **Claude Code** (terminal, con acceso SSH a la cuenta `u451636252`):

### Paso 1 — Traer el código real de rm360 como base
```bash
# Desde Claude Code, con SSH ya configurado a u451636252
scp -r usuario@servidor:/home/u451636252/domains/rm360.0km.app/* ./gochile-2.0-base/
```
O el equivalente con el gestor de archivos de hPanel si preferís no usar SSH directo.

### Paso 2 — Verificado ✅
Se confirmó contra los archivos reales (subidos desde rm360.0km.app, cuenta u451636252):
- `app/Models/Business.php` — `category()` y `media()` (morphMany a `Media`) existen tal cual se usaron en `BusinessResource`.
- `app/Models/Route.php` — `distance_km`, `duration_minutes`, `difficulty`, `destination()` coinciden exactamente con `RouteResource`.
- `app/Models/Concerns/HasGeoLocation.php` — el patrón `withCoordinates()` + `latitude`/`longitude` planos usado en todo este paquete es el real, sin diferencias.

No quedan dudas abiertas de este tipo. Lo que sigue siendo cierto: **go.0km.app hoy corre un proyecto distinto** (`go-chile-laravel-v4`, un sistema de talleres con `Workshop`/`Registration`, sin relación con rm360), así que el reemplazo de portada sigue siendo una instalación nueva, no un merge.

### Paso 3 — Aplicar los archivos de este paquete
Copiar cada archivo de `database/migrations/`, `app/Models/`, `app/Policies/`, `app/Http/Controllers/`, `app/Http/Resources/`, `resources/js/Pages/Public/` a las mismas rutas dentro del proyecto base traído en el Paso 1.

Registrar manualmente (están documentados en los `REGISTRAR_*.md` de este paquete):
- Rutas en `routes/web.php`
- Policies en `AuthServiceProvider`
- Morph map extendido en `AppServiceProvider` (ver `CORRECCION_FAVORITES.md`)

### Paso 4 — Migrar en un entorno de prueba primero
```bash
php artisan migrate --pretend   # ver el SQL sin ejecutar, primera pasada
php artisan migrate             # recién ahí en serio
php artisan db:seed --class=TerritorialHierarchySeeder
```
Recomendado: usar el staging de Hostinger (ya lo usaste para bodegaoutdoor.cl) antes de tocar el dominio final.

### Paso 5 — Recién ahí, apuntar go.0km.app al nuevo proyecto
Igual que se hizo con `rm360.0km.app` y `nahueltrek.cl`: copiar `public/*` a `public_html/`, symlink de storage, cron jobs de hPanel para scheduler/queue.

## Contenido de este paquete

| Carpeta | Contenido |
|---|---|
| `database/migrations/` | 14 migraciones nuevas (Fase 1 + Agenda reabierta) — **requieren el schema base de rm360 ya aplicado antes de correr** |
| `database/seeders/` | Seeder piloto de jerarquía territorial (solo RM) |
| `app/Models/` | 11 modelos nuevos/extendidos |
| `app/Policies/` | 5 policies nuevas |
| `app/Http/Controllers/` | 6 controladores (buscador, mapa, 4 fichas) |
| `app/Http/Resources/` | 7 API resources |
| `resources/js/Pages/Public/` | 7 páginas Vue (mobile-first) |
| `*.md` en la raíz | Notas de registro manual, correcciones aplicadas durante la sesión |

## Lo que falta de las fases originales

- Bitácora GO (frontend — el modelo/resource ya están, falta el controller + página Vue)
- Formulario de Colaboradores (frontend — modelo/policy ya están)
- Panel administrativo
- Panel autoadministrable para operadores
- Rebrand visual final de portada

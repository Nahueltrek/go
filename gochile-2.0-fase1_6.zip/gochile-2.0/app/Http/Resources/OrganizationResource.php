<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrganizationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'name' => $this->name,
            'slug' => $this->slug,
            'description' => $this->description,
            'commune' => $this->whenLoaded('commune', fn () => [
                'id' => $this->commune->id,
                'name' => $this->commune->name,
            ]),
            'categories' => $this->whenLoaded('categories', fn () => $this->categories->pluck('name')),
            'instagram' => $this->instagram,
            'website' => $this->website,
            'whatsapp' => $this->whatsapp,
            'logo_url' => $this->logo_url,
            // Requiere que el controller haya encadenado ->withCoordinates()
            // en la query — la columna 'location' es WKB binario crudo, no
            // legible directo desde PHP (ver HasGeoLocation::scopeWithCoordinates).
            'location' => $this->when($this->latitude !== null, fn () => [
                'lat' => $this->latitude,
                'lng' => $this->longitude,
            ]),
        ];
    }
}

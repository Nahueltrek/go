<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrganizationResource;
use App\Models\Organization;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class OrganizationController extends Controller
{
    public function index(Request $request): Response
    {
        $this->authorize('viewAny', Organization::class);

        $status = $request->query('status', 'approved');

        $organizations = Organization::with(['commune', 'categories'])
            ->when($status !== 'all', fn ($q) => $q->where('status', $status))
            ->latest()
            ->paginate(20);

        return Inertia::render('Admin/Organizaciones', [
            'organizations' => OrganizationResource::collection($organizations),
            'activeStatus' => $status,
        ]);
    }

    public function approve(Organization $organization): RedirectResponse
    {
        $this->authorize('approve', $organization);

        $organization->update(['status' => 'approved']);

        return back()->with('success', "{$organization->name} aprobado.");
    }

    public function suspend(Organization $organization): RedirectResponse
    {
        $this->authorize('approve', $organization); // mismo permiso que approve — solo admin

        $organization->update(['status' => 'rejected']);

        return back()->with('success', "{$organization->name} suspendido.");
    }
}

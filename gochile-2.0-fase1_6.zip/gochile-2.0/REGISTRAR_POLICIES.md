# Registrar en app/Providers/AuthServiceProvider.php

Agregar estas líneas al array `$policies` existente (no reemplazar el array completo — el que ya tiene rm360 registra Business, Route, etc., y esas entradas se mantienen):

```php
protected $policies = [
    // ... entradas existentes de rm360 (Business::class => BusinessPolicy::class, etc.) ...

    \App\Models\Organization::class => \App\Policies\OrganizationPolicy::class,
    \App\Models\Experience::class => \App\Policies\ExperiencePolicy::class,
    \App\Models\Project::class => \App\Policies\ProjectPolicy::class,
    \App\Models\BlogPost::class => \App\Policies\BlogPostPolicy::class,
    \App\Models\CollaborationRequest::class => \App\Policies\CollaborationRequestPolicy::class,
];
```

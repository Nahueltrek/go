# Agregar/reemplazar en routes/web.php

```php
use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'index'])->name('home');
```

Esta ruta **reemplaza** la que hoy sirve el home institucional de `go-chile-laravel-v4` (el de talleres). No se elimina ese proyecto — según lo acordado en `DEPLOY.md`, esto es una instalación nueva completa (código de rm360 + este paquete), así que la ruta `/` del proyecto nuevo simplemente nace apuntando a este `HomeController` desde el principio.

## Qué pasa con el taller actual ("Taller NDR + Práctico en Terreno")

No se migra automáticamente en este paquete. Camino recomendado una vez que el proyecto nuevo esté corriendo:
1. Crear manualmente en el admin la `Organization` de GO Chile (tipo `organizacion`).
2. Cargar el taller como un `Event` (categoría `formacion`) asociado a esa organización.

Esto queda pendiente de hacerse a mano al momento del deploy — no tiene sentido automatizarlo en una migración porque son datos reales, no estructura.

## Estado final del plan GO Chile 2.0

Con esta entrega quedan cubiertos todos los puntos del plan original excepto:
- CRUD de Bitácora desde el admin (solo lectura pública está lista)
- Panel autoadministrable para que cada operador gestione sus propias experiencias/eventos
- Carga real de datos (la red de colaboradores reales: Green Sport, Ríos Libres, etc.)

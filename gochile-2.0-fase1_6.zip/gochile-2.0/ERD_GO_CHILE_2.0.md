# GO Chile 2.0 — ERD y Modelo de Datos

Base técnica: schema de **Ruta Cajón del Maipo 360 (rm360)**, extendido para alcance nacional multi-actividad. Todo lo marcado `[EXISTE]` ya está en rm360 y se reutiliza sin tocar. Todo lo marcado `[NUEVO]` se agrega.

---

## 1. Jerarquía territorial

```
regions            [NUEVO — reemplaza el destino único de rm360]
├── id
├── name                  -- "Región Metropolitana", "Región de la Araucanía"
├── slug
└── code                  -- código oficial INE

provinces          [NUEVO]
├── id
├── region_id (FK regions)
├── name
└── slug

communes           [NUEVO]
├── id
├── province_id (FK provinces)
├── name
├── slug
└── centroid_lat / centroid_lng

destinations       [EXISTE — pasa de "1 registro piloto" a N registros]
├── id
├── commune_id (FK communes)      [NUEVO campo]
├── name                          -- ej. "Cajón del Maipo", "Araucanía Lacustre"
├── slug
├── description
├── is_active
└── active_layers (json)          -- categorías activas en ese destino
```

**Decisión clave:** en rm360, `destinations` era el Cajón del Maipo como registro único con `is_active`. En GO Chile 2.0, `destinations` se convierte en "zonas de interés turístico" (puede haber varias por comuna), y se agrega la jerarquía `regions → provinces → communes` arriba para que el mapa y el buscador puedan filtrar a nivel nacional.

---

## 2. Categorías / actividades

```
business_categories   [EXISTE — se amplía el catálogo]
├── id
├── name                 -- Trekking, Montañismo, Cicloturismo, Kayak, Escalada,
│                            Cabalgatas, Wellness, Conservación, Gastronomía,
│                            Alojamiento, Tours, Educación outdoor, Proyecto territorial
├── slug
├── map_layer             -- clave usada por el mapa para capas/colores
└── icon                  [NUEVO campo — ícono para el mapa/buscador]
```

---

## 3. Operadores (perfiles) — NUEVO

```
organizations      [NUEVO]
├── id
├── user_id (FK users)          -- dueño/admin del perfil
├── type                        -- guia | operador | agencia | emprendimiento |
│                                   alojamiento | marca | proyecto | organizacion
├── name
├── slug
├── description
├── commune_id (FK communes)
├── location (spatial, nullable)
├── instagram / website / whatsapp
├── logo_url
├── status                      -- pending | approved | rejected  (viene de "colaboradores")
└── created_at / updated_at

organization_categories   [NUEVO — pivot N:N]
├── organization_id
└── business_category_id
```

---

## 4. Experiencias — extiende el concepto de "business" de rm360

```
experiences         [NUEVO — reemplaza/extiende "businesses" de rm360 para
│                     casos que no son un local fijo sino una actividad]
├── id
├── organization_id (FK organizations)
├── destination_id (FK destinations, nullable)
├── name
├── slug
├── description
├── activity_type (FK business_categories)
├── difficulty          -- facil | medio | dificil | experto
├── duration_minutes
├── capacity
├── price
├── location (spatial)
├── status               -- draft | published | unpublished
├── is_featured
└── created_at / updated_at

-- Imágenes: NO se crea experience_images. Se reutiliza el modelo
-- polimórfico "media" [EXISTE] de rm360 (mediable_type/mediable_id),
-- el mismo que ya usan Attraction y otros modelos.

-- El modelo "businesses" [EXISTE] de rm360 (negocios con local fijo:
-- restaurantes, alojamiento) se mantiene tal cual y convive con "experiences".
```

---

## 5. Rutas de trekking — YA EXISTE, se reutiliza sin cambios

```
routes              [EXISTE]
route_points         [EXISTE — itinerario/trazado GPX]
```

---

## 6. Proyectos territoriales — NUEVO

```
projects            [NUEVO]
├── id
├── organization_id (FK organizations)
├── destination_id (FK destinations, nullable)
├── name
├── slug
├── description
├── category            -- conservacion | geologia | biodiversidad | comunidad
├── location (spatial, nullable)
├── how_to_collaborate (text)
└── status

-- Imágenes de proyectos: mismo criterio, reutiliza "media" polimórfico.
```

---

## 7. Agenda / Eventos — NUEVO (reemplaza la agenda estática actual de go.0km.app)

```
events               [NUEVO]
├── id
├── organization_id (FK organizations)
├── title
├── category            -- salidas | formacion | conservacion | cicloturismo | wellness | fotografia
├── description
├── starts_at / ends_at
├── location (spatial, nullable)
├── capacity
├── price
├── difficulty
└── status              -- draft | published | cancelled
```
Migración de datos: el taller fijo actual de GO Chile ("Taller NDR + Práctico en Terreno") se carga como el primer registro de `events`, con `organization_id` apuntando al perfil institucional de GO Chile.

---

## 8. Bitácora GO (blog editorial) — NUEVO

```
blog_posts           [NUEVO]
├── id
├── author_id (FK users)
├── title
├── slug
├── excerpt
├── content
├── category            -- rutas | personas | territorio | educacion | conservacion | experiencias
├── cover_image_url
├── related_organization_id (FK organizations, nullable)
├── related_destination_id (FK destinations, nullable)
├── status
└── published_at
```

---

## 9. Colaboradores (alta de operadores) — NUEVO

```
collaboration_requests   [NUEVO]
├── id
├── type                  -- mismo enum que organizations.type
├── name
├── region_id / commune_id
├── instagram / website / whatsapp
├── description
├── services (json)
├── images (json)
├── status                -- pending | approved | rejected
└── created_at
```
Al aprobarse, genera un registro en `organizations`.

---

## 10. Reseñas y favoritos — YA EXISTEN, se generalizan

```
reviews     [EXISTE]  -- se agrega reviewable_type/reviewable_id polimórfico
favorites   [EXISTE]  -- ídem, polimórfico para poder aplicar a experiences,
                          organizations, routes, projects y events
```

---

## 11. Relación general

```
Organization
 ├── Experiences
 ├── Routes (vía Experience o directo)
 ├── Events
 ├── Projects
 └── BlogPosts (como autor relacionado)

Destination (zona)
 ├── Experiences
 ├── Businesses [existente]
 ├── Routes [existente]
 └── Projects

Region → Province → Commune → (Destination | Organization | Experience | Project | Event)
```

---

## 12. Resumen de migraciones a crear

| Tabla | Estado |
|---|---|
| regions, provinces, communes | NUEVO |
| destinations | ALTER (agregar commune_id) |
| business_categories | ALTER (agregar icon) |
| organizations, organization_categories | NUEVO |
| experiences, experience_images | NUEVO |
| projects, project_images | NUEVO |
| events | NUEVO |
| blog_posts | NUEVO |
| collaboration_requests | NUEVO |
| reviews, favorites | ALTER (polimórfico) |
| businesses, routes, route_points | SIN CAMBIOS |

Todo esto se implementa como migraciones **incrementales** sobre el schema actual de rm360 — no se toca ninguna tabla existente salvo los 3 ALTER listados, y ninguno rompe datos ya cargados (Cilantro, la ruta a Laguna El Morado, etc. siguen intactos).

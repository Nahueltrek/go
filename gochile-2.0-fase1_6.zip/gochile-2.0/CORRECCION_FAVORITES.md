# Corrección: favorites NO necesita migración

`favorites` ya nace polimórfica en rm360 (`favoritable_type` + `favoritable_id`), usando un **morph map de strings cortos** (`'business'`, `'attraction'`, `'route'`) en vez de FQCN completo — por eso en el código de `FavoriteController` se ve `'type' => 'required|string|in:business,attraction,route'`.

Esto significa que para que GO Chile 2.0 permita favoritos sobre `experiences`, `organizations` y `projects`, **no se toca la tabla `favorites`** — solo hay que:

1. Extender el morph map (donde esté declarado — buscar `Relation::morphMap(` en el proyecto, probablemente en `AppServiceProvider::boot()`):

```php
use Illuminate\Database\Eloquent\Relations\Relation;

Relation::morphMap([
    // ... entradas existentes: 'business' => Business::class,
    //     'attraction' => Attraction::class, 'route' => Route::class ...
    'experience' => \App\Models\Experience::class,
    'organization' => \App\Models\Organization::class,
    'project' => \App\Models\Project::class,
]);
```

2. Agregar los nuevos tipos al `$allowedTypes` de `FavoriteController` y a la validación `in:business,attraction,route,experience,organization,project`.

## Corrección en Favorite.php

El modelo `Favorite.php` que te entregué en el paso anterior tenía un campo `business_id` legacy que **no existe en la tabla real**. Versión corregida (igual a la original de rm360, sin cambios — no hacía falta tocarla):

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Favorite extends Model
{
    protected $fillable = ['user_id', 'favoritable_type', 'favoritable_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function favoritable()
    {
        return $this->morphTo();
    }
}
```

Reemplazar el `Favorite.php` entregado antes por este.

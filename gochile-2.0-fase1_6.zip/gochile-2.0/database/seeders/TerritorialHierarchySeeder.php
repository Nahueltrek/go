<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TerritorialHierarchySeeder extends Seeder
{
    /**
     * Piloto: solo Región Metropolitana, Provincia Cordillera y sus comunas
     * relevantes para Cajón del Maipo. El resto de las 16 regiones / 56
     * provincias / 346 comunas de Chile se carga en una segunda pasada con
     * el dataset oficial del INE (pendiente — no fabricar códigos a mano).
     */
    public function run(): void
    {
        $regionId = DB::table('regions')->updateOrInsert(
            ['slug' => 'metropolitana-de-santiago'],
            [
                'name' => 'Región Metropolitana de Santiago',
                'code' => '13',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
        $regionId = DB::table('regions')->where('slug', 'metropolitana-de-santiago')->value('id');

        $provinceId = DB::table('provinces')->updateOrInsert(
            ['region_id' => $regionId, 'slug' => 'cordillera'],
            [
                'name' => 'Cordillera',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
        $provinceId = DB::table('provinces')->where('region_id', $regionId)->where('slug', 'cordillera')->value('id');

        $communes = [
            ['name' => 'San José de Maipo', 'slug' => 'san-jose-de-maipo', 'centroid_lat' => -33.6392, 'centroid_lng' => -70.3505],
            ['name' => 'Puente Alto', 'slug' => 'puente-alto', 'centroid_lat' => -33.6114, 'centroid_lng' => -70.5756],
            ['name' => 'Pirque', 'slug' => 'pirque', 'centroid_lat' => -33.6425, 'centroid_lng' => -70.5722],
        ];

        foreach ($communes as $commune) {
            DB::table('communes')->updateOrInsert(
                ['province_id' => $provinceId, 'slug' => $commune['slug']],
                array_merge($commune, [
                    'province_id' => $provinceId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ])
            );
        }

        // Vincula el destino piloto ya existente (Cajón del Maipo) a la
        // comuna San José de Maipo.
        $sanJoseId = DB::table('communes')->where('slug', 'san-jose-de-maipo')->value('id');
        DB::table('destinations')
            ->where('slug', 'cajon-del-maipo')
            ->update(['commune_id' => $sanJoseId]);
    }
}

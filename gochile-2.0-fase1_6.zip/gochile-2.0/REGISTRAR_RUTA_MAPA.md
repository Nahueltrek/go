# Registrar en routes/web.php

```php
use App\Http\Controllers\MapController;

Route::get('/mapa', [MapController::class, 'index'])->name('mapa');
Route::get('/mapa/geojson', [MapController::class, 'geojson'])->name('mapa.geojson');
```

## ⚠️ Verificar antes de producción: accessor de coordenadas

En el código real de rm360 que pude revisar, el mapa de Cajón del Maipo accede a las coordenadas como **propiedades planas**: `business.latitude`, `business.longitude` — no como `business.location.latitude`.

En `MapController::feature()` (este entregable) asumí `$location->latitude` / `$location->longitude`, es decir, que `location` es un objeto con esas propiedades (patrón común cuando `HasGeoLocation` castea la columna `POINT` a un value object). Puede que el trait real exponga en cambio accessors planos `getLatitudeAttribute()` / `getLongitudeAttribute()` directo en el modelo.

**Antes de correr esto**: revisar `App\Models\Concerns\HasGeoLocation.php` real y ajustar `MapController::feature()` según corresponda — es un cambio de una línea si el patrón es distinto, pero rompe todo el mapa si no se corrige.

## Fuera de esta entrega

- **Rutas de trekking (`routes`)** no están en el GeoJSON — son polilíneas (`route_points`), no puntos, y necesitan una capa de líneas separada en MapLibre (`type: 'line'`), no el mismo tratamiento que el resto. Se deja para una iteración siguiente del mapa.

# Agregar en routes/web.php

```php
use App\Http\Controllers\BlogPostController;
use App\Http\Controllers\CollaborationController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CollaborationRequestController;
use App\Http\Controllers\Admin\OrganizationController as AdminOrganizationController;

// --- Bitácora (pública) ---
Route::get('/bitacora', [BlogPostController::class, 'index'])->name('bitacora.index');
Route::get('/bitacora/{slug}', [BlogPostController::class, 'show'])->name('bitacora.show');

// --- Colaboradores (pública, sin auth) ---
Route::get('/colaboradores', [CollaborationController::class, 'create'])->name('colaboradores.create');
Route::post('/colaboradores', [CollaborationController::class, 'store'])->name('colaboradores.store');

// --- Panel admin (requiere rol admin — usa el middleware EnsureUserHasRole
// que ya existe en rm360, mismo patrón que el admin actual) ---
Route::middleware(['auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/colaboradores', [CollaborationRequestController::class, 'index'])->name('colaboradores.index');
    Route::post('/colaboradores/{collaborationRequest}/approve', [CollaborationRequestController::class, 'approve'])->name('colaboradores.approve');
    Route::post('/colaboradores/{collaborationRequest}/reject', [CollaborationRequestController::class, 'reject'])->name('colaboradores.reject');

    Route::get('/organizaciones', [AdminOrganizationController::class, 'index'])->name('organizaciones.index');
    Route::post('/organizaciones/{organization}/approve', [AdminOrganizationController::class, 'approve'])->name('organizaciones.approve');
    Route::post('/organizaciones/{organization}/suspend', [AdminOrganizationController::class, 'suspend'])->name('organizaciones.suspend');
});
```

## Nota sobre el middleware `role:admin`

Asumí que existe un middleware `role` registrado (rm360 tiene `EnsureUserHasRole` según lo documentado en memoria del proyecto). Si el alias real es distinto, ajustar la línea del `Route::middleware([...])` — es un cambio de una palabra, no de estructura.

## Bitácora — falta el `Admin\BlogPostController` de creación/edición

Esta entrega cubre la **lectura pública** de la Bitácora y la **aprobación de colaboradores/operadores** desde el admin. Todavía falta:
- CRUD de artículos de Bitácora desde el admin (crear/editar/publicar) — el modelo y policy ya existen (`BlogPost`, `BlogPostPolicy`), falta el controller admin y el formulario Vue.
- CRUD de experiencias/proyectos desde el panel autoadministrable de cada operador (la "Fase 15" del plan original) — más grande, se deja para una iteración aparte.

# GO Chile 2.0 — Fase 1: Migraciones sobre base rm360

## Contenido de esta entrega

**15 migraciones** en `database/migrations/`, numeradas para correr en orden después de las 36 ya existentes de rm360:

1. `regions`, `provinces`, `communes` — jerarquía territorial nacional (nuevo)
2. ALTER `destinations` — agrega `commune_id`
3. ALTER `business_categories` — agrega `icon`
4. `organizations` + `organization_categories` — perfiles de operador/guía/agencia/etc.
5. `experiences` + `experience_images`
6. `projects` + `project_images`
7. `blog_posts`
8. `collaboration_requests`
9. ALTER `reviews` y `favorites` — pasan a polimórficos, con backfill automático de los datos existentes de `business_id`

**1 seeder** — `TerritorialHierarchySeeder.php`: carga solo Región Metropolitana → Cordillera → (San José de Maipo, Puente Alto, Pirque) como piloto, y vincula el destino "Cajón del Maipo" existente a su comuna.

**Sin tocar**: `businesses`, `routes`, `route_points` y todo lo demás de rm360 sigue funcionando igual. `events` queda fuera de esta fase (pendiente, según lo acordado).

## Decisiones técnicas y riesgos

- **`reviews`/`favorites` polimórficos**: se agregan las columnas nuevas y se hace backfill automático desde `business_id`, pero **no se elimina `business_id`** todavía. Esto es intencional — se verifica en producción que el backfill dio 100% de coincidencias antes de dropear la columna legacy en una migración separada.
- **Ubicación (`location`) en `organizations`, `experiences`, `projects`**: se agregó como `POINT NULL` **sin spatial index**, a diferencia de rm360 donde `location` es `NOT NULL` con índice espacial. Se decidió así porque no todo operador/experiencia va a tener coordenadas desde el día 1 (ej. una agencia sin local fijo). Si más adelante se necesita spatial index para el mapa nacional, hay que migrar esa columna a `NOT NULL` — y ahí aplica el mismo cuidado que en rm360: asignar `location` **antes** del primer `save()`, no después.
- **Jerarquía territorial nacional**: el seeder solo carga la Región Metropolitana como piloto. Completar las 16 regiones / 56 provincias / 346 comunas de Chile requiere el dataset oficial del INE — no se fabricaron códigos a mano para evitar datos incorrectos.

## Pendiente explícito (fuera de esta fase)

- `events` (agenda) — dejado pendiente por decisión tuya.
- Dataset completo de regiones/provincias/comunas de Chile.
- Drop de `business_id` legacy en `reviews`/`favorites` tras verificar backfill en producción.
- Modelos Eloquent, policies y API resources para las tablas nuevas (siguiente paso).

## Cómo correr esto

```bash
php artisan migrate
php artisan db:seed --class=TerritorialHierarchySeeder
```

Recomendado: correrlo primero en un entorno de staging o con backup de la base, ya que toca `reviews` y `favorites` en producción.

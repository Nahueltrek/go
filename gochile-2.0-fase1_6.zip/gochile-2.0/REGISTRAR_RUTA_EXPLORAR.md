# Agregar en routes/web.php (junto a las rutas públicas existentes de rm360)

```php
use App\Http\Controllers\SearchController;

Route::get('/explorar', [SearchController::class, 'index'])->name('explorar');
```

No requiere autenticación — es una ruta pública, igual que `/mapa` y las fichas de negocio existentes.

# Agregar en routes/web.php

```php
use App\Http\Controllers\OrganizationController;
use App\Http\Controllers\ExperienceController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\EventController;

Route::get('/operadores/{slug}', [OrganizationController::class, 'show'])->name('operadores.show');
Route::get('/experiencias/{slug}', [ExperienceController::class, 'show'])->name('experiencias.show');
Route::get('/proyectos/{slug}', [ProjectController::class, 'show'])->name('proyectos.show');
Route::get('/agenda', [EventController::class, 'index'])->name('agenda.index');
Route::get('/agenda/{slug}', [EventController::class, 'show'])->name('agenda.show');
```

Todas públicas, sin auth. `firstOrFail()` en cada controller devuelve 404 automático de Laravel si el slug no existe o no está publicado/aprobado.

# GO Chile 2.0 — Comandos de deploy en go.0km.app

Contexto: cuenta Hostinger `u451636252`, PHP 8.3 vía alt-php, sin sudo/Docker/Redis
(mismo entorno que rm360.0km.app y nahueltrek.cl). Reemplazá `<...>` por tus valores.

---

## 0. Backup antes de tocar nada

```bash
ssh u451636252@<tu-host-ssh> -p 65002   # puerto SSH de Hostinger, revisar en hPanel

# Backup de la base actual de go.0km.app (la de talleres) por si se necesita
# recuperar algo — NO se va a reutilizar, pero mejor tenerla.
mysqldump -u <usuario_db_actual> -p <nombre_db_actual> > ~/backup_go_talleres_$(date +%Y%m%d).sql
```

---

## 1. Traer el código base de rm360 como punto de partida

```bash
cd ~/domains
mkdir -p go.0km.app_new
cp -r rm360.0km.app/* go.0km.app_new/
cp -r rm360.0km.app/.env.example go.0km.app_new/.env  # partir del .env.example, no del real
cd go.0km.app_new
```

No copiar el `.env` real de rm360 — tiene credenciales de OTRA base de datos. Se arma uno nuevo en el paso 4.

---

## 2. Subir y aplicar el paquete GO Chile 2.0

Desde tu máquina local (no en el servidor), subí `gochile-2.0-fase1.zip` a esta carpeta nueva, por ejemplo con el file manager de hPanel o `scp`:

```bash
scp -P 65002 gochile-2.0-fase1.zip u451636252@<tu-host-ssh>:~/domains/go.0km.app_new/
```

Ya en el servidor:

```bash
cd ~/domains/go.0km.app_new
unzip gochile-2.0-fase1.zip -d /tmp/gochile-2.0-extract

# Copiar cada carpeta a su lugar (rsync no pisa lo que no está en el paquete)
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/database/migrations/ database/migrations/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/database/seeders/ database/seeders/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/app/Models/ app/Models/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/app/Policies/ app/Policies/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/app/Http/Controllers/ app/Http/Controllers/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/app/Http/Resources/ app/Http/Resources/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/resources/js/Pages/Public/ resources/js/Pages/Public/
rsync -av /tmp/gochile-2.0-extract/gochile-2.0/resources/js/Pages/Admin/ resources/js/Pages/Admin/

rm -rf /tmp/gochile-2.0-extract
```

**Después de esto, aplicar a mano** los cambios documentados en los `*.md` del paquete (no son archivos que se copien, son ediciones sobre archivos existentes):
- `routes/web.php` ← todos los `REGISTRAR_RUTA*.md`
- `app/Providers/AuthServiceProvider.php` ← `REGISTRAR_POLICIES.md`
- `app/Providers/AppServiceProvider.php` (morph map) ← `CORRECCION_FAVORITES.md`

---

## 3. Instalar dependencias

```bash
/opt/alt/php83/usr/bin/php -v   # confirmar que es la 8.3 correcta antes de seguir
/opt/alt/php83/usr/bin/php $(which composer) install --no-dev --optimize-autoloader

npm install
npm run build
```

---

## 4. Configurar `.env`

```bash
nano .env
```

Ajustar como mínimo:
```
APP_NAME="GO Chile"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://go.0km.app

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_DATABASE=<crear una base nueva en hPanel, ej. u451636252_gochile>
DB_USERNAME=<usuario db nuevo>
DB_PASSWORD=<password — si tiene # u otros caracteres especiales, ir entre comillas>

CACHE_STORE=database
QUEUE_CONNECTION=database
SESSION_DRIVER=database
```

```bash
/opt/alt/php83/usr/bin/php artisan key:generate
```

---

## 5. Migrar (en dos pasadas: primero solo mirar, después en serio)

```bash
# Ver el SQL que se va a ejecutar, sin tocar la base todavía
/opt/alt/php83/usr/bin/php artisan migrate --pretend

# Recién ahí, en serio — esto corre las 36+ migraciones de rm360 PRIMERO
# (ya están en database/migrations/ porque vienen del código base copiado
# en el paso 1) y después las 16 nuevas de GO Chile 2.0, en orden por fecha.
/opt/alt/php83/usr/bin/php artisan migrate

/opt/alt/php83/usr/bin/php artisan db:seed --class=TerritorialHierarchySeeder
```

Si algo falla acá, **no reintentar a ciegas** — pegame el error exacto y lo resolvemos antes de seguir.

---

## 6. Storage y assets

```bash
# Igual que en nahueltrek.cl: si storage:link falla en este hosting,
# usar el disk "live" apuntando directo a public_html/uploads en vez de symlink.
/opt/alt/php83/usr/bin/php artisan storage:link
```

---

## 7. Publicar (apuntar el dominio a esta carpeta)

En hPanel → Dominios → `go.0km.app` → cambiar el "document root" para que apunte a:
```
~/domains/go.0km.app_new/public
```

O, si tu hosting no permite cambiar el document root fácilmente (como pasó con rm360/nahueltrek), copiar el contenido de `public/*` al `public_html` real de `go.0km.app`:

```bash
cp -r public/* ~/domains/go.0km.app/public_html/
```

---

## 8. Cron y queue worker (hPanel → Cron Jobs)

```
* * * * * cd ~/domains/go.0km.app_new && /opt/alt/php83/usr/bin/php artisan schedule:run >> /dev/null 2>&1
```

Para el queue worker, agregar un cron cada minuto que reintente procesar (no hay proceso persistente en shared hosting):
```
* * * * * cd ~/domains/go.0km.app_new && /opt/alt/php83/usr/bin/php artisan queue:work --stop-when-empty >> /dev/null 2>&1
```

---

## 9. Verificación final

```bash
/opt/alt/php83/usr/bin/php artisan route:list | grep -E "explorar|mapa|bitacora|colaboradores|admin"
curl -I https://go.0km.app
```

Y en el navegador: `/`, `/explorar`, `/mapa`, `/bitacora`, `/colaboradores`, `/admin` (con un usuario admin creado a mano vía `tinker` o seeder si no existe todavía).

<script setup>
import { ref } from 'vue'
import { router, Link } from '@inertiajs/vue3'

defineProps({
  activities: Array,
  featuredExperiences: Object,
  upcomingEvents: Object,
  latestPosts: Object,
  networkOrganizations: Object,
})

const q = ref('')

function goExplorar(activitySlug = null) {
  router.get('/explorar', {
    q: q.value || undefined,
    activity: activitySlug || undefined,
  })
}
</script>

<template>
  <div class="min-h-screen bg-white">
    <!-- Hero -->
    <section class="px-4 pt-8 pb-6 bg-neutral-900 text-white">
      <p class="text-xs uppercase tracking-widest text-neutral-400">🇨🇱 GO Chile</p>
      <h1 class="text-2xl font-semibold mt-2 leading-tight">
        Descubre Chile outdoor
      </h1>
      <p class="text-sm text-neutral-300 mt-2 leading-relaxed">
        Encuentra rutas, experiencias, operadores y proyectos que conectan personas con la naturaleza.
      </p>

      <form @submit.prevent="goExplorar()" class="relative mt-5">
        <input
          v-model="q"
          type="search"
          placeholder="¿Qué querés hacer? Trekking, rafting, wellness…"
          class="w-full rounded-full bg-white py-3.5 pl-11 pr-4 text-sm text-neutral-900
                 placeholder:text-neutral-400 focus:outline-none"
        />
        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400">🔎</span>
      </form>
    </section>

    <!-- Explorar por actividad -->
    <section class="px-4 py-6">
      <h2 class="text-sm font-semibold text-neutral-900 mb-3">Explora por actividad</h2>
      <div class="grid grid-cols-4 gap-3">
        <button
          v-for="a in activities.slice(0, 8)"
          :key="a.id"
          @click="goExplorar(a.slug)"
          class="flex flex-col items-center gap-1.5 rounded-2xl bg-neutral-50 py-3 active:bg-neutral-100"
        >
          <span class="text-xl">{{ a.icon || '📍' }}</span>
          <span class="text-[11px] text-neutral-600 text-center leading-tight">{{ a.name }}</span>
        </button>
      </div>
    </section>

    <!-- Mapa CTA -->
    <section class="px-4 pb-6">
      <Link href="/mapa" class="block rounded-2xl bg-neutral-50 border border-neutral-100 p-4 flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-neutral-900">🗺️ Mapa GO Chile</p>
          <p class="text-xs text-neutral-500 mt-0.5">Todo el ecosistema outdoor, en un mapa</p>
        </div>
        <span class="text-neutral-400">→</span>
      </Link>
    </section>

    <!-- Experiencias destacadas -->
    <section v-if="featuredExperiences.data?.length" class="px-4 py-6 border-t border-neutral-100">
      <div class="flex items-center justify-between mb-3">
        <h2 class="text-sm font-semibold text-neutral-900">Experiencias destacadas</h2>
        <Link href="/explorar" class="text-xs text-neutral-400">Ver todas</Link>
      </div>
      <div class="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4">
        <Link
          v-for="exp in featuredExperiences.data"
          :key="exp.id"
          :href="`/experiencias/${exp.slug}`"
          class="shrink-0 w-40 rounded-2xl border border-neutral-100 overflow-hidden"
        >
          <div class="h-24 w-full bg-neutral-100">
            <img v-if="exp.images?.[0]" :src="exp.images[0]" class="h-full w-full object-cover" />
          </div>
          <div class="p-2.5">
            <p class="text-xs font-medium text-neutral-900 truncate">{{ exp.name }}</p>
            <p class="text-[11px] text-neutral-400 truncate">{{ exp.organization?.name }}</p>
          </div>
        </Link>
      </div>
    </section>

    <!-- Agenda próxima -->
    <section v-if="upcomingEvents.data?.length" class="px-4 py-6 border-t border-neutral-100">
      <div class="flex items-center justify-between mb-3">
        <h2 class="text-sm font-semibold text-neutral-900">📅 Próximas actividades</h2>
        <Link href="/agenda" class="text-xs text-neutral-400">Ver agenda</Link>
      </div>
      <div class="space-y-2">
        <Link
          v-for="e in upcomingEvents.data"
          :key="e.id"
          :href="`/agenda/${e.slug}`"
          class="flex items-center gap-3 rounded-xl border border-neutral-100 p-2.5"
        >
          <div class="text-sm font-medium text-neutral-900 truncate flex-1">{{ e.title }}</div>
          <div class="text-xs text-neutral-400 capitalize">{{ e.category }}</div>
        </Link>
      </div>
    </section>

    <!-- Red de colaboradores -->
    <section v-if="networkOrganizations.data?.length" class="px-4 py-6 border-t border-neutral-100">
      <h2 class="text-sm font-semibold text-neutral-900 mb-3">Nuestra red</h2>
      <div class="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4">
        <Link
          v-for="org in networkOrganizations.data"
          :key="org.id"
          :href="`/operadores/${org.slug}`"
          class="shrink-0 flex flex-col items-center gap-1.5 w-16"
        >
          <div class="h-14 w-14 rounded-full bg-neutral-100 overflow-hidden">
            <img v-if="org.logo_url" :src="org.logo_url" class="h-full w-full object-cover" />
          </div>
          <p class="text-[10px] text-neutral-600 text-center truncate w-full">{{ org.name }}</p>
        </Link>
      </div>
    </section>

    <!-- Bitácora -->
    <section v-if="latestPosts.data?.length" class="px-4 py-6 border-t border-neutral-100">
      <div class="flex items-center justify-between mb-3">
        <h2 class="text-sm font-semibold text-neutral-900">Bitácora GO</h2>
        <Link href="/bitacora" class="text-xs text-neutral-400">Ver todo</Link>
      </div>
      <div class="space-y-3">
        <Link
          v-for="post in latestPosts.data"
          :key="post.id"
          :href="`/bitacora/${post.slug}`"
          class="flex gap-3"
        >
          <div class="h-14 w-14 shrink-0 rounded-xl bg-neutral-100 overflow-hidden">
            <img v-if="post.cover_image_url" :src="post.cover_image_url" class="h-full w-full object-cover" />
          </div>
          <div class="min-w-0">
            <p class="text-xs uppercase tracking-wide text-neutral-400">{{ post.category }}</p>
            <p class="text-sm font-medium text-neutral-900 truncate">{{ post.title }}</p>
          </div>
        </Link>
      </div>
    </section>

    <!-- CTA colaboradores -->
    <section class="px-4 py-8 border-t border-neutral-100">
      <div class="rounded-2xl bg-neutral-900 text-white p-5 text-center">
        <p class="text-sm font-medium">🤝 ¿Sos guía, operador o tenés un proyecto territorial?</p>
        <Link href="/colaboradores" class="inline-block mt-3 text-xs font-medium rounded-full bg-white text-neutral-900 px-4 py-2">
          Quiero ser parte de GO Chile
        </Link>
      </div>
    </section>
  </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar { display: none; }
.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
</style>

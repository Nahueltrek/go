<script setup>
import { router, Link } from '@inertiajs/vue3'

const props = defineProps({
  posts: Object,
  activeCategory: String,
  categories: Array,
})

function filterBy(key) {
  router.get('/bitacora', key === props.activeCategory ? {} : { category: key }, { preserveState: true })
}
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <header class="px-4 pt-6 pb-4 border-b border-neutral-100">
      <h1 class="text-lg font-semibold text-neutral-900">Bitácora GO</h1>
      <p class="text-xs text-neutral-400 mt-1">Contenido generado desde el territorio</p>

      <div class="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
        <button
          v-for="cat in categories"
          :key="cat.key"
          @click="filterBy(cat.key)"
          class="shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors"
          :class="activeCategory === cat.key ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-600'"
        >{{ cat.label }}</button>
      </div>
    </header>

    <div class="px-4 py-4 space-y-4">
      <Link
        v-for="post in posts.data"
        :key="post.id"
        :href="`/bitacora/${post.slug}`"
        class="block rounded-2xl border border-neutral-100 overflow-hidden active:bg-neutral-50"
      >
        <div class="h-40 w-full bg-neutral-100">
          <img v-if="post.cover_image_url" :src="post.cover_image_url" class="h-full w-full object-cover" />
        </div>
        <div class="p-3">
          <p class="text-xs uppercase tracking-wide text-neutral-400">{{ post.category }}</p>
          <p class="text-sm font-semibold text-neutral-900 mt-0.5">{{ post.title }}</p>
          <p v-if="post.excerpt" class="text-xs text-neutral-500 mt-1 line-clamp-2">{{ post.excerpt }}</p>
        </div>
      </Link>

      <p v-if="!posts.data?.length" class="text-sm text-neutral-400 text-center py-12">
        Todavía no hay artículos publicados{{ activeCategory ? ' en esta categoría' : '' }}.
      </p>
    </div>
  </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar { display: none; }
.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
</style>

<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  post: Object,
  related: Object,
})
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <div class="h-56 w-full bg-neutral-100 overflow-hidden">
      <img v-if="post.cover_image_url" :src="post.cover_image_url" class="h-full w-full object-cover" />
    </div>

    <div class="px-4 py-5">
      <p class="text-xs uppercase tracking-wide text-neutral-400">{{ post.category }}</p>
      <h1 class="text-xl font-semibold text-neutral-900 mt-0.5">{{ post.title }}</h1>
      <p class="text-xs text-neutral-400 mt-1">{{ post.published_at }}</p>

      <Link
        v-if="post.related_organization"
        :href="`/operadores/${post.related_organization.slug}`"
        class="text-sm text-neutral-500 underline block mt-2"
      >{{ post.related_organization.name }}</Link>

      <div class="prose prose-sm max-w-none mt-6 text-neutral-700 leading-relaxed whitespace-pre-line">
        {{ post.content }}
      </div>
    </div>

    <section v-if="related?.data?.length" class="px-4 py-6 border-t border-neutral-100 space-y-3">
      <h2 class="text-sm font-semibold text-neutral-900">Te puede interesar</h2>
      <Link
        v-for="r in related.data"
        :key="r.id"
        :href="`/bitacora/${r.slug}`"
        class="flex gap-3 rounded-2xl border border-neutral-100 p-3 active:bg-neutral-50"
      >
        <div class="h-14 w-14 shrink-0 rounded-xl bg-neutral-100 overflow-hidden">
          <img v-if="r.cover_image_url" :src="r.cover_image_url" class="h-full w-full object-cover" />
        </div>
        <p class="text-sm font-medium text-neutral-900 self-center">{{ r.title }}</p>
      </Link>
    </section>
  </div>
</template>

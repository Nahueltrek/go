<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  experience: Object,
  reviews: Array,
})
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <!-- Galería -->
    <div class="h-56 w-full bg-neutral-100 overflow-hidden">
      <img v-if="experience.images?.[0]" :src="experience.images[0]" class="h-full w-full object-cover" />
    </div>

    <div class="px-4 py-5">
      <p class="text-xs uppercase tracking-wide text-neutral-400">{{ experience.activity_type }}</p>
      <h1 class="text-xl font-semibold text-neutral-900 mt-0.5">{{ experience.name }}</h1>

      <Link
        v-if="experience.organization"
        :href="`/operadores/${experience.organization.slug}`"
        class="text-sm text-neutral-500 underline"
      >{{ experience.organization.name }}</Link>

      <!-- Datos clave -->
      <div class="grid grid-cols-2 gap-3 mt-5">
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Dificultad</p>
          <p class="text-sm font-medium text-neutral-900 capitalize">{{ experience.difficulty || '—' }}</p>
        </div>
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Duración</p>
          <p class="text-sm font-medium text-neutral-900">
            {{ experience.duration_minutes ? `${experience.duration_minutes} min` : '—' }}
          </p>
        </div>
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Capacidad</p>
          <p class="text-sm font-medium text-neutral-900">{{ experience.capacity || '—' }}</p>
        </div>
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Precio</p>
          <p class="text-sm font-medium text-neutral-900">
            {{ experience.price ? `$${experience.price.toLocaleString('es-CL')}` : 'Consultar' }}
          </p>
        </div>
      </div>

      <p v-if="experience.description" class="text-sm text-neutral-600 mt-5 leading-relaxed">
        {{ experience.description }}
      </p>

      <!-- Reseñas -->
      <section v-if="reviews?.length" class="mt-8 space-y-3">
        <h2 class="text-sm font-semibold text-neutral-900">Reseñas</h2>
        <div v-for="(r, i) in reviews" :key="i" class="rounded-xl border border-neutral-100 p-3">
          <p class="text-sm text-neutral-900">{{ '★'.repeat(r.rating) }}{{ '☆'.repeat(5 - r.rating) }}</p>
          <p v-if="r.comment" class="text-sm text-neutral-600 mt-1">{{ r.comment }}</p>
          <p class="text-xs text-neutral-400 mt-1">{{ r.user_name }}</p>
        </div>
      </section>
    </div>

    <!-- CTA fijo -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-100 px-4 py-3">
      <a
        v-if="experience.organization?.whatsapp"
        :href="`https://wa.me/${experience.organization.whatsapp}`"
        class="block text-center text-sm font-medium rounded-full bg-neutral-900 text-white py-3"
      >Reservar por WhatsApp</a>
    </div>
  </div>
</template>

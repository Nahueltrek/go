<script setup>
import { Link } from '@inertiajs/vue3'

const props = defineProps({
  event: Object,
})

function formatDate(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleDateString('es-CL', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })
}
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <div class="h-56 w-full bg-neutral-100 overflow-hidden">
      <img v-if="event.cover_image" :src="event.cover_image" class="h-full w-full object-cover" />
    </div>

    <div class="px-4 py-5">
      <p class="text-xs uppercase tracking-wide text-neutral-400">{{ event.category }}</p>
      <h1 class="text-xl font-semibold text-neutral-900 mt-0.5">{{ event.title }}</h1>

      <Link
        v-if="event.organization"
        :href="`/operadores/${event.organization.slug}`"
        class="text-sm text-neutral-500 underline"
      >{{ event.organization.name }}</Link>

      <div class="grid grid-cols-2 gap-3 mt-5">
        <div class="rounded-xl bg-neutral-50 p-3 col-span-2">
          <p class="text-xs text-neutral-400">Fecha</p>
          <p class="text-sm font-medium text-neutral-900">{{ formatDate(event.starts_at) }}</p>
        </div>
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Cupos</p>
          <p class="text-sm font-medium text-neutral-900">{{ event.capacity || 'Sin límite' }}</p>
        </div>
        <div class="rounded-xl bg-neutral-50 p-3">
          <p class="text-xs text-neutral-400">Precio</p>
          <p class="text-sm font-medium text-neutral-900">
            {{ event.price ? `$${event.price.toLocaleString('es-CL')}` : 'Gratis' }}
          </p>
        </div>
      </div>

      <p v-if="event.description" class="text-sm text-neutral-600 mt-5 leading-relaxed">
        {{ event.description }}
      </p>
    </div>

    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-100 px-4 py-3">
      <a
        v-if="event.organization?.whatsapp"
        :href="`https://wa.me/${event.organization.whatsapp}`"
        class="block text-center text-sm font-medium rounded-full bg-neutral-900 text-white py-3"
      >Reservar por WhatsApp</a>
    </div>
  </div>
</template>

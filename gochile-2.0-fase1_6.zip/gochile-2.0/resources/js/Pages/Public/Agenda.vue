<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  events: Object,
})

function formatDate(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleDateString('es-CL', { day: 'numeric', month: 'short' })
}
</script>

<template>
  <div class="min-h-screen bg-white pb-12">
    <header class="px-4 pt-6 pb-4 border-b border-neutral-100">
      <h1 class="text-lg font-semibold text-neutral-900">Agenda GO Chile</h1>
      <p class="text-xs text-neutral-400 mt-1">Próximas salidas, talleres y actividades</p>
    </header>

    <div class="px-4 py-4 space-y-3">
      <Link
        v-for="e in events.data"
        :key="e.id"
        :href="`/agenda/${e.slug}`"
        class="flex gap-3 rounded-2xl border border-neutral-100 p-3 active:bg-neutral-50"
      >
        <div class="flex flex-col items-center justify-center h-14 w-14 shrink-0 rounded-xl bg-neutral-900 text-white">
          <span class="text-xs font-medium">{{ formatDate(e.starts_at) }}</span>
        </div>
        <div class="min-w-0 flex-1">
          <p class="text-sm font-medium text-neutral-900 truncate">{{ e.title }}</p>
          <p class="text-xs text-neutral-500 truncate">{{ e.organization?.name }}</p>
          <p class="text-xs text-neutral-400 mt-0.5 capitalize">{{ e.category }}</p>
        </div>
      </Link>

      <p v-if="!events.data?.length" class="text-sm text-neutral-400 text-center py-12">
        No hay eventos próximos por ahora.
      </p>
    </div>
  </div>
</template>

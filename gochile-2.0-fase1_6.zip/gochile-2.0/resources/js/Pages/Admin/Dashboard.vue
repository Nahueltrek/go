<script setup>
import { Link } from '@inertiajs/vue3'

defineProps({
  stats: Object,
})

const cards = [
  { key: 'colaboraciones_pendientes', label: 'Postulaciones pendientes', href: '/admin/colaboradores', highlight: true },
  { key: 'organizaciones_pendientes', label: 'Operadores pendientes', href: '/admin/organizaciones?status=pending', highlight: true },
  { key: 'organizaciones_aprobadas', label: 'Operadores activos', href: '/admin/organizaciones' },
  { key: 'experiencias_publicadas', label: 'Experiencias publicadas' },
  { key: 'proyectos_publicados', label: 'Proyectos publicados' },
  { key: 'eventos_proximos', label: 'Eventos próximos', href: '/agenda' },
  { key: 'articulos_publicados', label: 'Artículos en Bitácora', href: '/bitacora' },
]
</script>

<template>
  <div class="min-h-screen bg-neutral-50 px-4 py-6">
    <h1 class="text-lg font-semibold text-neutral-900 mb-4">Panel GO Chile</h1>

    <div class="grid grid-cols-2 gap-3">
      <component
        v-for="c in cards"
        :key="c.key"
        :is="c.href ? Link : 'div'"
        :href="c.href"
        class="rounded-2xl bg-white border p-4"
        :class="c.highlight && stats[c.key] > 0 ? 'border-amber-300' : 'border-neutral-100'"
      >
        <p class="text-2xl font-semibold text-neutral-900">{{ stats[c.key] }}</p>
        <p class="text-xs text-neutral-500 mt-1">{{ c.label }}</p>
      </component>
    </div>
  </div>
</template>

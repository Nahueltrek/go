<?php

use App\Http\Controllers\Public\AttractionShowController;
use App\Http\Controllers\Public\BusinessShowController;
use App\Http\Controllers\Public\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', HomeController::class)->name('home');
Route::get('/emprendimientos/{slug}', BusinessShowController::class)->name('businesses.show');
Route::get('/atractivos/{slug}', AttractionShowController::class)->name('attractions.show');

// NOTA: /rutas/{slug} y /blog/{slug} quedan para la próxima fase — no se
// pidieron en esta pasada de "fichas de negocio/atractivo".
